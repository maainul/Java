package com._11july2020;


public class _6_AddTwoNumbers {

	ListNode headListNode;

	public static class ListNode {
		int data;
		ListNode nextListNode;

		public ListNode(int data) {
			this.data = data;
			this.nextListNode = null;
		}
	}

	public void insertAtLast(int data) {
		ListNode newNode = new ListNode(data);
		if (headListNode == null) {
			headListNode = newNode;
		} else {
			ListNode currentListNode = headListNode;
			while (currentListNode.nextListNode != null) {
				currentListNode = currentListNode.nextListNode;
			}
			currentListNode.nextListNode = newNode;
		}
	}

	public void display() {
		ListNode tempListNode = headListNode;
		while (tempListNode != null) {
			System.out.print(tempListNode.data + " ");
			tempListNode = tempListNode.nextListNode;
		}
	}

	public static void display(ListNode headListNode) {
		ListNode tempListNode = headListNode;
		while (tempListNode != null) {
			System.out.print(tempListNode.data + " ");
			tempListNode = tempListNode.nextListNode;
		}
	}

	public static void main(String[] args) {
		_6_AddTwoNumbers obj1 = new _6_AddTwoNumbers();

		obj1.insertAtLast(5);
		obj1.insertAtLast(6);
		obj1.insertAtLast(3);

		System.out.println("\nLinked list 1 :");
		obj1.display();

		_6_AddTwoNumbers obj2 = new _6_AddTwoNumbers();
		obj2.insertAtLast(8);
		obj2.insertAtLast(4);
		obj2.insertAtLast(2);

		System.out.println("\nLinked list 2 :");
		obj2.display();

		System.out.println("\nAddition of linked list");

		ListNode resultListNode = addtion(obj1.headListNode, obj2.headListNode);

		
		display(resultListNode);
	}

	private static ListNode addtion(ListNode l1, ListNode l2) {
		 ListNode prev = null;
	        ListNode res = null;
	        ListNode temp = null;
	        int sum = 0, carry = 0;
	        int p1,p2;
	        while(l1 != null || l2 != null){
	            if(l1 != null){
	                p1 = l1.data;
	                l1 = l1.nextListNode;
	            }else{
	                p1 = 0;
	            }
	            if(l2 != null){
	                p2 = l2.data;
	                l2 = l2.nextListNode;
	            }else{
	                p2 = 0;
	            }

	            sum = carry + p1 + p2;
	            carry = ( sum >= 10 ? 1 : 0 );
	            sum = sum % 10;
	            temp = new ListNode(sum);

	            if(res == null){
	                res = temp;
	            }else{
	                prev.nextListNode = temp;
	            }
	            prev = temp;
	        }
	        if(carry >0){
	            temp.nextListNode = new ListNode(carry);
	        }
	        return res;

	}

}
