package com._11july2020;

public class _2_FibonacciNumber {

	public static void main(String[] args) {

		int num = 9;

		System.out.println(fibonacci(num));

		for (int i = 0; i <= num; i++) {
			System.out.print(fibonacci(i) + ", ");
		}

	}

	private static int fibonacci(int num) {
		if (num < 2) {
			return num;
		}

		int a = 0;
		int b = 1;
		int c = 1;

		for (int i = 2; i <= num; i++) {
			a = b + c;
			b = c;
			c = a;
		}
		return b;
	}

}
