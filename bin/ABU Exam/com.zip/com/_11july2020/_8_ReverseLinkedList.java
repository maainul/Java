package com._11july2020;

public class _8_ReverseLinkedList {

	ListNode headListNode;

	public class ListNode {
		int data;
		ListNode nextListNode;

		public ListNode(int data) {
			this.data = data;
			this.nextListNode = null;
		}
	}

	public void insertAtLast(int data) {
		ListNode newNode = new ListNode(data);
		if (headListNode == null) {
			headListNode = newNode;
		} else {
			ListNode currentListNode = headListNode;
			while (currentListNode.nextListNode != null) {
				currentListNode = currentListNode.nextListNode;
			}
			currentListNode.nextListNode = newNode;
		}
	}

	public void display(ListNode headListNode) {
		ListNode tempListNode = headListNode;
		while (tempListNode != null) {
			System.out.print(tempListNode.data + " ");
			tempListNode = tempListNode.nextListNode;
		}
	}

	public static void main(String[] args) {
		_8_ReverseLinkedList obj = new _8_ReverseLinkedList();

		obj.insertAtLast(3);
		obj.insertAtLast(4);
		obj.insertAtLast(5);
		obj.insertAtLast(7);
		obj.insertAtLast(9);
		obj.display(obj.headListNode);

		System.out.println("\nReverse of linked list");
		ListNode resultListNode = obj.reverse();
		obj.display(resultListNode);

	}

	private ListNode reverse() {
		ListNode previousListNode = null;
		ListNode currentListNode = headListNode;
		ListNode nextListNode = null;

		while (currentListNode != null) {
			nextListNode = currentListNode.nextListNode;
			currentListNode.nextListNode = previousListNode;
			previousListNode = currentListNode;
			currentListNode = nextListNode;
		}
		return previousListNode;
	}

}
