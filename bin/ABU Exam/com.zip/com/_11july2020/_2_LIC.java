package com._11july2020;

import java.util.Arrays;

public class _2_LIC {

	public static void main(String[] args) {
		int[] nums = {10, 22, 9, 33, 21, 50, 41, 60, 80};

		System.out.println(Arrays.toString(nums));
		
		int result = findLengthOfLCIS(nums);
		System.out.println("\nLength: ");
		System.out.println(result);
	}
	
    public static int findLengthOfLCIS(int[] nums) {
        int temp = 1;
       // System.out.print(nums[0]+ ", ");
        for(int i=0; i < nums.length-1; i++){
            if(nums[i] < nums[i+1]){
            	nums[temp] = nums[i+1];
               // System.out.print(nums[temp]+", ");
                temp++;
            }
        }// 41 60 80 
        return temp;
    }
}

