package com._11july2020;

public class _7_FindMiddleOfLinkedList {

	ListNode headListNode;

	public class ListNode {
		int data;
		ListNode nextListNode;

		public ListNode(int data) {
			this.data = data;
			this.nextListNode = null;
		}
	}

	public void insertAtLast(int data) {
		ListNode newNode = new ListNode(data);
		if (headListNode == null) {
			headListNode = newNode;
		} else {
			ListNode currentListNode = headListNode;
			while (currentListNode.nextListNode != null) {
				currentListNode = currentListNode.nextListNode;
			}
			currentListNode.nextListNode = newNode;
		}
	}

	public void display() {
		ListNode tempListNode = headListNode;
		while (tempListNode != null) {
			System.out.print(tempListNode.data + " ");
			tempListNode = tempListNode.nextListNode;
		}
	}

	public static void main(String[] args) {
		_7_FindMiddleOfLinkedList obj = new _7_FindMiddleOfLinkedList();

		obj.insertAtLast(3);
		obj.insertAtLast(4);
		obj.insertAtLast(5);
		obj.insertAtLast(7);
		obj.insertAtLast(9);
		// obj.insertAtLast(10);
		obj.display();

		System.out.println("\nMiddle of linked list");
		System.out.println(obj.middle());
	}

	private int middle() {

		ListNode slowListNode = headListNode;
		ListNode fastListNode = headListNode;

		while (fastListNode != null && fastListNode.nextListNode != null) {
			slowListNode = slowListNode.nextListNode;
			fastListNode = fastListNode.nextListNode.nextListNode;
		}

		return slowListNode.data;

	}

}
