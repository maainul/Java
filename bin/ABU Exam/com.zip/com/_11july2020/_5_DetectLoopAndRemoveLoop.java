package com._11july2020;

public class _5_DetectLoopAndRemoveLoop {
	Node head;

	static class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
			this.next = null;
		}
	}
	public void findLoop() {
		Node q = head;
		Node p = head;
		while (p != null && q != null && q.next != null) {
			q = q.next.next;
			p = p.next;
			if (p == q) {
				System.out.print("\nLoop is Found");
				remove(p, head);
			}
		}
	}

	public void remove(Node p, Node head) {
		Node t = head;
		while (p.next != t) {
			p = p.next;
			t = t.next;
		}
		p.next = null;
	}

	void display(Node node) {
		while (node != null) {
			System.out.print(node.data + " ");
			node = node.next;
		}
	}

	// Driver program to test above functions
	public static void main(String[] args) {
		_5_DetectLoopAndRemoveLoop list = new _5_DetectLoopAndRemoveLoop();

		list.head = new Node(1);
		list.head.next = new Node(2);
		list.head.next.next = new Node(3);
		list.head.next.next.next = new Node(4);
		list.head.next.next.next.next = new Node(5);

		list.display(list.head);

		// loop
		list.head.next.next.next.next.next = list.head.next;

		list.findLoop();
	
		System.out.println("\nLinked List after removing loop : ");
		list.display(list.head);
	}
}