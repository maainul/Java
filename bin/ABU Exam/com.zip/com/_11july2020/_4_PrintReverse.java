package com._11july2020;

public class _4_PrintReverse {

	ListNode headListNode;

	public class ListNode {
		int data;
		ListNode nextListNode;

		public ListNode(int data) {
			this.data = data;
			this.nextListNode = null;
		}
	}

	public void insertAtLast(int data) {
		ListNode newNode = new ListNode(data);
		if (headListNode == null) {
			headListNode = newNode;
		} else {
			ListNode currentListNode = headListNode;
			while (currentListNode.nextListNode != null) {
				currentListNode = currentListNode.nextListNode;
			}
			currentListNode.nextListNode = newNode;
		}
	}

	public void display() {
		ListNode tempListNode = headListNode;
		while (tempListNode != null) {
			System.out.print(tempListNode.data + " ");
			tempListNode = tempListNode.nextListNode;
		}
	}

	public static void main(String[] args) {
		_4_PrintReverse obj = new _4_PrintReverse();

		obj.insertAtLast(3);
		obj.insertAtLast(4);
		obj.insertAtLast(5);
		obj.insertAtLast(7);
		obj.insertAtLast(9);

		System.out.println("Original of linked list");
		obj.display();

		System.out.println("\n\nReverseLinked List: ");
		obj.reverse(obj.headListNode);
	}

	private void reverse(ListNode headListNode) {
		if (headListNode == null) {
			return;
		}

		reverse(headListNode.nextListNode);

		System.out.print(headListNode.data + " ");

	}

}
