package nov25._2_insertionOfTwoLinkedList;

public class Node {
	int data;
	Node headNode;
	Node next;
	
	public Node(int data) {
		this.data = data;
		this.next = null;
		
		
		
	}

}
